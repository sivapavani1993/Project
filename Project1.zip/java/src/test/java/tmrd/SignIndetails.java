package tmrd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignIndetails {
	WebDriver driver;
	By signin = By.xpath("//button[@class='appearance-outline size-small status-warning shape-round icon-start ng-star-inserted transitions']");
	By username= By.name("usernameUserInput");
	By Password= By.name("password");
	By Continue= By.xpath("//button[@class='ui primary large button']");
	
	SignIndetails(WebDriver d)
	{
		driver=d;
		
	}
	public void clicksignIn() {
		driver.findElement(signin).click();;
	}
	public void setusername(String uname) {
		driver.findElement(username).sendKeys(uname);
	}
    public void setPassword(String password) {
    	driver.findElement(Password).sendKeys(password);
    }
    public void clickContinue() {
    	driver.findElement(Continue).click();
    }
}

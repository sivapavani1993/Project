package tmrd;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class VerifySignInpage {
	WebDriver driver;
	
	
	@Test
	public void signIntest() throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		SignIndetails sdpage = new SignIndetails(driver);
		driver.manage().window().maximize();
		driver.get("https://exchange.oip.tmrnd.com.my");
		Thread.sleep(10000);
		sdpage.clicksignIn();
		sdpage.setusername("siva.chinna36@gmail.com");
		sdpage.setPassword("Siva@pavani1");
		sdpage.clickContinue();
		Thread.sleep(3000);
		TakesScreenshot ts=  (TakesScreenshot)driver;
		File file= ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("./Scrrenshot/Image1.png/"));
		driver.quit();
	}

}
